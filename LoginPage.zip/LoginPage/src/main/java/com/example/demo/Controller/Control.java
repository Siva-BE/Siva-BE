package com.example.demo.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.Entity.Login;
import com.example.demo.Repository.Repo;

@Controller
@RequestMapping("/api")
public class Control {
	
	@Autowired
	Repo rep;

    @GetMapping("/login")
    public String showLoginForm() {
    	rep.findAll();
    	
        return "login";
    }
    @PostMapping("/welcome")
    public String welcomemsg(Login login) {
    	rep.save(login);
    	
    	return "welcome";
    }
    @DeleteMapping("/delete")
    @ResponseBody
    public void deletedata() {
    	rep.deleteAll();
    }
}
