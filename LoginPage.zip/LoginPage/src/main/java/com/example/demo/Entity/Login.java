package com.example.demo.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="user_data")
public class Login {
	
	@Id
	@Column
	private String Username;
	@Column
	private String Password;
	
	public Login() {
		
	}
	
	public Login(String username, String password) {
		super();
		Username = username;
		Password = password;
	}
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}


	@Override
	public String toString() {
		return "Login [Username=" + Username + ", Password=" + Password + "]";
	}

	
	
}
